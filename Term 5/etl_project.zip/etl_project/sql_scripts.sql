-- 1
insert into p3.tgss_rep_fraud(event_dt,passport,fio,phone, event_type,report_dt)
select
distinct 
first_value(tst.transaction_date) over(partition  by passport_num) event_dt,
  clients.passport_num passport,
  concat_ws(' ', clients.last_name, clients.first_name, clients.patronymic) fio,
  clients.phone,
  1 event_type, 
  current_timestamp report_dt
FROM p3.tgss_dwh_fact_transactions tst
INNER JOIN p3.tgss_dwh_dim_cards_hist cards ON tst.card_num = cards.card_num
INNER JOIN p3.tgss_dwh_dim_accounts_hist accounts ON cards.account_num = accounts.account_id
INNER JOIN p3.tgss_dwh_dim_clients_hist clients ON clients.client_id = accounts.client
WHERE
(clients.passport_num in (SELECT passport_num FROM p3.tgss_dwh_fact_passport_blacklist) OR
clients.passport_valid_to < tst.transaction_date)
and clients.passport_valid_to is not null
and tst.transaction_date >cards.effective_from 
and tst.transaction_date < cards.effective_to
and tst.transaction_date >accounts.effective_from 
and tst.transaction_date < accounts.effective_to 
and tst.transaction_date >clients.effective_from 
and tst.transaction_date < clients.effective_to 
;

-- 2
insert into p3.tgss_rep_fraud(event_dt,passport,fio,phone, event_type,report_dt)
select
distinct 
first_value(tst.transaction_date) over(partition  by passport_num) event_dt,
tsc.passport_num passport,
concat_ws(' ', tsc.last_name, tsc.first_name, tsc.patronymic) fio,
tsc.phone phone,
2 event_type, 
current_timestamp report_dt

from p3.tgss_dwh_fact_transactions tst
inner join (p3.tgss_dwh_dim_cards_hist c
inner join (p3.tgss_dwh_dim_accounts_hist a
inner join p3.tgss_dwh_dim_clients_hist tsc 
on tsc.client_id =  a.client)
on c.account_num = a.account_id)
on tst.card_num  = c.card_num
where 
a.valid_to<=tst.transaction_date 
and tst.transaction_date > c.effective_from 
and tst.transaction_date < c.effective_to 
and tst.transaction_date > a.effective_from 
and tst.transaction_date < a.effective_to 
and tst.transaction_date > tsc.effective_from 
and tst.transaction_date < tsc.effective_to
;



-- 3
insert into p3.tgss_rep_fraud(event_dt,passport,fio,phone, event_type,report_dt)
with w_city as (
select tst.*,tst2.terminal_city from p3.tgss_dwh_fact_transactions tst
inner join p3.tgss_dwh_dim_terminals_hist tst2 
on tst.terminal=tst2.terminal_id
where 
tst.transaction_date > tst2.effective_from 
and tst.transaction_date < tst2.effective_to 
)
, dop as (
select 
lead(r) over(partition by card_num,terminal_city order by transaction_date) r_l,*
from(
select 
rank() over (partition by card_num,terminal_city order by transaction_date) r,
lag(terminal_city) over(partition by card_num,terminal_city order by transaction_date) pr_city,
* from w_city
) a)
, fnd as(
select * from dop
where 
r_l is null and
pr_city is null
),
needed_card as (
select distinct last_value(card_num) over(partition by card_num,terminal_city order by transaction_date) card_num
, tdt
from ( 
select 
date_part('hour', dop.transaction_date - fnd.transaction_date) prt,
dop.*, fnd.transaction_date tdt from dop
inner join fnd
on dop.card_num = fnd.card_num
where date_part('hour', dop.transaction_date - fnd.transaction_date)>=-1
and date_part('hour', dop.transaction_date - fnd.transaction_date)<=1
) a
)

select
distinct 
first_value(nc.tdt) over(partition  by passport_num) event_dt,
tsc.passport_num passport,
concat_ws(' ', tsc.last_name, tsc.first_name, tsc.patronymic) fio,
tsc.phone phone,
3 event_type, 
current_timestamp report_dt

from needed_card nc
inner join (p3.tgss_dwh_dim_cards_hist c 
inner join (p3.tgss_dwh_dim_accounts_hist a
inner join p3.tgss_dwh_dim_clients_hist tsc 
on tsc.client_id =  a.client)
on c.account_num = a.account_id)
on nc.card_num  = c.card_num

where 
1=1
and nc.tdt > c.effective_from 
and nc.tdt < c.effective_to 
and nc.tdt > a.effective_from 
and nc.tdt < a.effective_to 
and nc.tdt > tsc.effective_from 
and nc.tdt < tsc.effective_to 
;






-- 4
insert into p3.tgss_rep_fraud(event_dt,passport,fio,phone, event_type,report_dt)
with
wot as(
select * from p3.tgss_dwh_fact_transactions tst
where oper_result ='REJECT'
)
, reject as(
select 
ld.*
from
(select *
,lead(transaction_date) over(partition by card_num order by transaction_date) as dt_l
,lead(amount) over(partition by card_num order by transaction_date) as a_l
,lead(transaction_id) over(partition by card_num order by transaction_date) as id_l
from wot
) ld 
where
date_part('minute',ld.dt_l-ld.transaction_date)<20
and date_part('minute',ld.dt_l-ld.transaction_date)>=0
and ld.a_l < ld.amount
)
,next_tst as(
select *,
lead(transaction_id) over(partition by card_num order by transaction_date) next_id
from p3.tgss_dwh_fact_transactions tst
),

res as (
select 
tst.*
from
p3.tgss_dwh_fact_transactions tst,
(
select next_tst.*, r.id_l
from next_tst
inner join reject r
on r.id_l = next_tst.transaction_id
) n

where tst.oper_result ='SUCCESS'
and n.next_id = tst.transaction_id
and date_part('minute',tst.transaction_date-n.transaction_date)<20
and date_part('minute',tst.transaction_date-n.transaction_date)>=0
and tst.amount < n.amount
)

select
distinct 
first_value(res.transaction_date) over(partition  by passport_num) event_dt,
tsc.passport_num passport,
concat_ws(' ', tsc.last_name, tsc.first_name, tsc.patronymic) fio,
tsc.phone phone,
4 event_type, 
current_timestamp report_dt

from res
inner join (p3.tgss_dwh_dim_cards_hist c
inner join (p3.tgss_dwh_dim_accounts_hist a
inner join p3.tgss_dwh_dim_clients_hist tsc 
on tsc.client_id =  a.client)
on c.account_num = a.account_id)
on res.card_num  = c.card_num

where 
1=1
and res.transaction_date > c.effective_from 
and res.transaction_date < c.effective_to 
and res.transaction_date > a.effective_from 
and res.transaction_date < a.effective_to 
and res.transaction_date > tsc.effective_from 
and res.transaction_date < tsc.effective_to 