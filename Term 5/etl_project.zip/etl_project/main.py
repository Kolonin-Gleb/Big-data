import psycopg2
import pandas as pd
import numpy as np
import os
 
# Создание подключения к PostgreSQL
conn = psycopg2.connect(database = "home",
                        host =     "212.8.247.94",
                        user =     "student",
                        password = "qwerty",
                        port =     "5432")
# Отключение автокоммита
conn.autocommit = False
# Создание курсора
cursor = conn.cursor()

"""## Accounts"""

def load_accounts():
  cursor.execute("delete from p3.tgss_stg_accounts")
  conn.commit()
  cursor.execute("delete from p3.tgss_stg_del_accounts")
  conn.commit()
  cursor.execute( "INSERT INTO p3.tgss_STG_accounts select * from bank.accounts")
  conn.commit()



  q='''
  insert into p3.tgss_stg_del_accounts select account from bank.accounts;


  -- 4 этап
  -- Запись данных в детальный слой
  insert into p3.tgss_dwh_dim_accounts_hist (account_id, valid_to, client, effective_from)
  select
      t1.account_id,
      t1.valid_to,
      t1.client,
      t1.create_dt
  from p3.tgss_stg_accounts t1
  left join p3.tgss_dwh_dim_accounts_hist t2
  on t1.account_id = t2.account_id
  where t2.account_id is null;

  -- 5 этап
  -- Обновление данных в детальном слое
  update p3.tgss_dwh_dim_accounts_hist 
  set
      effective_to = upd.create_dt - interval '1 minute'
  from (
      select
          t1.account_id,
          t1.valid_to,
          t1.client,
          t1.create_dt
      from p3.tgss_stg_accounts t1
      inner join p3.tgss_dwh_dim_accounts_hist t2
      on t2.account_id = t1.account_id
      where 
          (t1.client <> t2.client or (t1.client is null and t2.client is not null) or (t1.client is not null and t2.client is null))
    or (t1.valid_to <> t2.valid_to or (t1.valid_to is null and t2.valid_to is not null) or (t1.valid_to is not null and t2.valid_to is null))
  ) upd
  where tgss_dwh_dim_accounts_hist.account_id = upd.account_id;

  insert into p3.tgss_dwh_dim_accounts_hist (account_id, valid_to, client, effective_from)
  select
      t1.account_id,
      t1.valid_to,
      t1.client,
      t1.create_dt
  from p3.tgss_stg_accounts t1
  inner join p3.tgss_dwh_dim_accounts_hist t2
  on t2.account_id = t1.account_id
  where 
    (t1.client <> t2.client or (t1.client is null and t2.client is not null) or (t1.client is not null and t2.client is null))
    or (t1.valid_to <> t2.valid_to or (t1.valid_to is null and t2.valid_to is not null) or (t1.valid_to is not null and t2.valid_to is null));
  

  -- 6 этап
  -- Удаленные записи:
  
  -- записываем удаленную запись 
  insert into p3.tgss_dwh_dim_accounts_hist (account_id, valid_to, client, effective_from, deleted_flg)
  select
        t1.account_id,
        t1.valid_to,
        t1.client,
        now(),
        True
  from p3.tgss_dwh_dim_accounts_hist t1
  left join p3.tgss_stg_del_accounts t2
  on t1.account_id = t2.account_id
  where t1.effective_to = to_timestamp('2999-12-31', 'YYYY-MM-DD') and t2.account_id is null and t1.deleted_flg = False;

  -- апдейтим старую запись (закрываем актуальность)
  update p3.tgss_dwh_dim_accounts_hist tgt
  set
    effective_to = now() - interval '1 minute'
  where 
    1=1
    and effective_to = to_timestamp('2999-12-31', 'YYYY-MM-DD') 
    and deleted_flg = False
    and account_id in (
        select
            t1.account_id 
        from p3.tgss_dwh_dim_accounts_hist t1
        left join p3.tgss_stg_del_accounts t2
        on t1.account_id = t2.account_id 
        where t2.account_id is null );

  -- 7 этап
  -- Обновление мета-данных
  update p3.tgss_meta
  set last_update_dt = coalesce((select max(create_dt) from p3.tgss_stg_accounts), (select last_update_dt from p3.tgss_meta where schema = 'p3' and table_name = 'tgss_dwh_dim_accounts_hist'))
  where schema = 'p3' and table_name = 'tgss_dwh_dim_accounts_hist';

  -- 8 этап
  -- Фиксация транзакции
  --commit;
  '''

  cursor.execute(q)
  conn.commit()
  cursor.execute('select * from p3.tgss_dwh_dim_accounts_hist')
  # cursor.execute('select create_dt from p3.tgss_stg_accounts')
  records = cursor.fetchall()
  # for row in records:
  #     print( row )

"""## Cards"""

def load_cards():
  cursor.execute("delete from p3.tgss_stg_cards")
  conn.commit()
  cursor.execute("delete from p3.tgss_stg_del_cards")
  conn.commit()
  cursor.execute( "INSERT INTO p3.tgss_STG_cards select * from bank.cards")
  conn.commit()



  q='''
  -- 4 этап
  -- Запись данных в детальный слой
  insert into p3.tgss_dwh_dim_cards_hist (card_num, account_num, effective_from)
  select
      t1.card_num,
      t1.account,
      t1.create_dt
  from p3.tgss_stg_cards t1
  left join p3.tgss_dwh_dim_cards_hist t2
  on t1.card_num = t2.card_num
  where t2.card_num is null;

  -- 5 этап
  -- Обновление данных в детальном слое
  update p3.tgss_dwh_dim_cards_hist 
  set
      effective_to = upd.create_dt - interval '1 minute'
  from (
      select
        t1.card_num,
        t1.account,
        t1.create_dt
      from p3.tgss_stg_cards t1
      inner join p3.tgss_dwh_dim_cards_hist t2
      on t2.card_num = t1.card_num
      where 
          t1.account <> t2.account_num or (t1.account is null and t2.account_num is not null) or (t1.account is not null and t2.account_num is null)
  ) upd
  where tgss_dwh_dim_cards_hist.card_num = upd.card_num;

  insert into p3.tgss_dwh_dim_cards_hist (card_num, account_num, effective_from)
  select
      t1.card_num,
      t1.account,
      t1.create_dt
  from p3.tgss_stg_cards t1
  inner join p3.tgss_dwh_dim_cards_hist t2
  on t2.card_num = t1.card_num
  where 
    t1.account <> t2.account_num or (t1.account is null and t2.account_num is not null) or (t1.account is not null and t2.account_num is null);
  

  -- 6 этап
  -- Удаленные записи:
  
  -- записываем удаленную запись 
  insert into p3.tgss_dwh_dim_cards_hist (card_num, account_num, effective_from, deleted_flg)
  select
        t1.card_num,
        t1.account_num,
        now(),
        True
  from p3.tgss_dwh_dim_cards_hist t1
  left join p3.tgss_stg_del_cards t2
  on t1.card_num = t2.card_num
  where t1.effective_to = to_timestamp('2999-12-31', 'YYYY-MM-DD') and t2.card_num is null and t1.deleted_flg = False;

  -- апдейтим старую запись (закрываем актуальность)
  update p3.tgss_dwh_dim_cards_hist tgt
  set
    effective_to = now() - interval '1 minute'
  where 
    1=1
    and effective_to = to_timestamp('2999-12-31', 'YYYY-MM-DD') 
    and deleted_flg = False
    and card_num in (
        select
            t1.card_num 
        from p3.tgss_dwh_dim_cards_hist t1
        left join p3.tgss_stg_del_cards t2
        on t1.card_num = t2.card_num 
        where t2.card_num is null );

  -- 7 этап
  -- Обновление мета-данных
  update p3.tgss_meta
  set last_update_dt = coalesce((select max(create_dt) from p3.tgss_stg_cards), (select last_update_dt from p3.tgss_meta where schema = 'p3' and table_name = 'tgss_dwh_dim_cards_hist'))
  where schema = 'p3' and table_name = 'tgss_dwh_dim_cards_hist';

  -- 8 этап
  -- Фиксация транзакции
  --commit;
  '''

  cursor.execute('insert into p3.tgss_stg_del_cards select card_num from bank.cards')
  conn.commit()

  cursor.execute(q)
  conn.commit()
  cursor.execute('select * from p3.tgss_dwh_dim_cards_hist')
  # cursor.execute('select * from p3.tgss_stg_cards')
  records = cursor.fetchall()


"""## Clients"""

def load_clients():
  cursor.execute("delete from p3.tgss_stg_clients")
  conn.commit()
  cursor.execute("delete from p3.tgss_stg_del_clients")
  conn.commit()
  cursor.execute( "INSERT INTO p3.tgss_STG_clients select * from bank.clients")
  conn.commit()


  q='''
  -- 4 этап
  -- Запись данных в детальный слой
  insert into p3.tgss_dwh_dim_clients_hist (client_id, last_name, first_name, patronymic, date_of_birth, passport_num, passport_valid_to, phone,  effective_from)
  select
      t1.client_id,
      t1.last_name,
      t1.first_name,
      t1.patronymic,
      t1.date_of_birth,
      t1.passport_num,
      t1.passport_valid_to,
      t1.phone,
      t1.create_dt
  from p3.tgss_stg_clients t1
  left join p3.tgss_dwh_dim_clients_hist t2
  on t1.client_id = t2.client_id
  where t2.client_id is null;

  -- 5 этап
  -- Обновление данных в детальном слое
  update p3.tgss_dwh_dim_clients_hist 
  set
      effective_to = upd.create_dt - interval '1 minute'
  from (
      select
        t1.client_id,
      t1.last_name,
      t1.first_name,
      t1.patronymic,
      t1.date_of_birth,
      t1.passport_num,
      t1.passport_valid_to,
      t1.phone,
        t1.create_dt
      from p3.tgss_stg_clients t1
      inner join p3.tgss_dwh_dim_clients_hist t2
      on t2.client_id = t1.client_id
      where 
          (t1.last_name <> t2.last_name or (t1.last_name is null and t2.last_name is not null) or (t1.last_name is not null and t2.last_name is null))
          or (t1.patronymic <> t2.patronymic or (t1.patronymic is null and t2.patronymic is not null) or (t1.patronymic is not null and t2.patronymic is null))
          or (t1.first_name <> t2.first_name or (t1.first_name is null and t2.first_name is not null) or (t1.first_name is not null and t2.first_name is null))
          or (t1.date_of_birth <> t2.date_of_birth or (t1.date_of_birth is null and t2.date_of_birth is not null) or (t1.date_of_birth is not null and t2.date_of_birth is null))
          or (t1.phone <> t2.phone or (t1.phone is null and t2.phone is not null) or (t1.phone is not null and t2.phone is null))
  ) upd
  where tgss_dwh_dim_clients_hist.client_id = upd.client_id;

  insert into p3.tgss_dwh_dim_clients_hist (client_id, last_name, first_name, patronymic, date_of_birth, passport_num, passport_valid_to, phone,  effective_from)
  select
      t1.client_id,
      t1.last_name,
      t1.first_name,
      t1.patronymic,
      t1.date_of_birth,
      t1.passport_num,
      t1.passport_valid_to,
      t1.phone,
      t1.create_dt
  from p3.tgss_stg_clients t1
  inner join p3.tgss_dwh_dim_clients_hist t2
  on t2.client_id = t1.client_id
  where 
    (t1.last_name <> t2.last_name or (t1.last_name is null and t2.last_name is not null) or (t1.last_name is not null and t2.last_name is null))
          or (t1.patronymic <> t2.patronymic or (t1.patronymic is null and t2.patronymic is not null) or (t1.patronymic is not null and t2.patronymic is null))
          or (t1.first_name <> t2.first_name or (t1.first_name is null and t2.first_name is not null) or (t1.first_name is not null and t2.first_name is null))
          or (t1.date_of_birth <> t2.date_of_birth or (t1.date_of_birth is null and t2.date_of_birth is not null) or (t1.date_of_birth is not null and t2.date_of_birth is null))
          or (t1.phone <> t2.phone or (t1.phone is null and t2.phone is not null) or (t1.phone is not null and t2.phone is null));
  

  -- 6 этап
  -- Удаленные записи:
  
  -- записываем удаленную запись 
  insert into p3.tgss_dwh_dim_clients_hist (client_id, last_name, first_name, patronymic, date_of_birth, passport_num, passport_valid_to, phone,  effective_from, deleted_flg)
  select
      t1.client_id,
      t1.last_name,
      t1.first_name,
      t1.patronymic,
      t1.date_of_birth,
      t1.passport_num,
      t1.passport_valid_to,
      t1.phone,
    now(),
    True
  from p3.tgss_dwh_dim_clients_hist t1
  left join p3.tgss_stg_del_clients t2
  on t1.client_id = t2.client_id
  where t1.effective_to = to_timestamp('2999-12-31', 'YYYY-MM-DD') and t2.client_id is null and t1.deleted_flg = False;

  -- апдейтим старую запись (закрываем актуальность)
  update p3.tgss_dwh_dim_clients_hist tgt
  set
    effective_to = now() - interval '1 minute'
  where 
    1=1
    and effective_to = to_timestamp('2999-12-31', 'YYYY-MM-DD') 
    and deleted_flg = False
    and client_id in (
        select
            t1.client_id 
        from p3.tgss_dwh_dim_clients_hist t1
        left join p3.tgss_stg_del_clients t2
        on t1.client_id = t2.client_id 
        where t2.client_id is null );

  -- 7 этап
  -- Обновление мета-данных
  update p3.tgss_meta
  set last_update_dt = coalesce((select max(create_dt) from p3.tgss_stg_clients), (select last_update_dt from p3.tgss_meta where schema = 'p3' and table_name = 'tgss_dwh_dim_clients_hist'))
  where schema = 'p3' and table_name = 'tgss_dwh_dim_clients_hist';

  -- 8 этап
  -- Фиксация транзакции
  --commit;
  '''

  cursor.execute('insert into p3.tgss_stg_del_clients select client_id from bank.clients')
  conn.commit()

  cursor.execute(q)
  conn.commit()
  cursor.execute('select * from p3.tgss_dwh_dim_clients_hist')
  # cursor.execute('select * from p3.tgss_stg_cards')
  records = cursor.fetchall()


"""## Terminals"""

def load_terminals(file):
  cursor.execute("delete from p3.tgss_stg_terminals")
  conn.commit()
  cursor.execute("delete from p3.tgss_stg_del_terminals")
  conn.commit()
  cursor.executemany( "INSERT INTO p3.tgss_STG_terminals( terminal_id, terminal_type, terminal_city,terminal_address) VALUES( %s, %s,%s, %s )", file.values.tolist() )
  conn.commit()


  q='''
  -- 4 этап
  -- Запись данных в детальный слой
  insert into p3.tgss_dwh_dim_terminals_hist (terminal_id, terminal_type, terminal_city, terminal_address)
  select
        t1.terminal_id,
        t1.terminal_type,
        t1.terminal_city,
        t1.terminal_address
  from p3.tgss_stg_terminals t1
  left join p3.tgss_dwh_dim_terminals_hist t2
  on t1.terminal_id = t2.terminal_id
  where t2.terminal_id is null;

  -- 5 этап
  -- Обновление данных в детальном слое
  update p3.tgss_dwh_dim_terminals_hist 
  set
      effective_to = upd.effective_from - interval '1 minute'
  from (
      select
        t1.terminal_id,
        t1.terminal_type,
        t1.terminal_city,
        t1.terminal_address,
        now() effective_from
      from p3.tgss_stg_terminals t1
      inner join p3.tgss_dwh_dim_terminals_hist t2
      on t2.terminal_id = t1.terminal_id
      where 
          (t1.terminal_type <> t2.terminal_type or (t1.terminal_type is null and t2.terminal_type is not null) or (t1.terminal_type is not null and t2.terminal_type is null))
          or (t1. terminal_city <> t2. terminal_city or (t1. terminal_city is null and t2. terminal_city is not null) or (t1. terminal_city is not null and t2. terminal_city is null))
          or (t1. terminal_address <> t2. terminal_address or (t1. terminal_address is null and t2. terminal_address is not null) or (t1. terminal_address is not null and t2. terminal_address is null))
  ) upd
  where tgss_dwh_dim_terminals_hist.terminal_id = upd.terminal_id;

  insert into p3.tgss_dwh_dim_terminals_hist (terminal_id, terminal_type, terminal_city, terminal_address)
  select
        t1.terminal_id,
        t1.terminal_type,
        t1.terminal_city,
        t1.terminal_address
  from p3.tgss_stg_terminals t1
  inner join p3.tgss_dwh_dim_terminals_hist t2
  on t2.terminal_id = t1.terminal_id
  where 
          (t1.terminal_type <> t2.terminal_type or (t1.terminal_type is null and t2.terminal_type is not null) or (t1.terminal_type is not null and t2.terminal_type is null))
          or (t1. terminal_city <> t2. terminal_city or (t1. terminal_city is null and t2. terminal_city is not null) or (t1. terminal_city is not null and t2. terminal_city is null))
          or (t1. terminal_address <> t2. terminal_address or (t1. terminal_address is null and t2. terminal_address is not null) or (t1. terminal_address is not null and t2. terminal_address is null)) 
  ;
  -- 6 этап
  -- Удаленные записи:
  
  -- записываем удаленную запись 
  insert into p3.tgss_dwh_dim_terminals_hist (terminal_id, terminal_type, terminal_city, terminal_address, effective_from, deleted_flg)
  select
          t1.terminal_id,
          t1.terminal_type,
          t1.terminal_city,
          t1.terminal_address,
        now(),
        True
  from p3.tgss_dwh_dim_terminals_hist t1
  left join p3.tgss_stg_del_terminals t2
  on t1.terminal_id = t2.terminal_id
  where t1.effective_to = to_timestamp('2999-12-31', 'YYYY-MM-DD') and t2.terminal_id is null and t1.deleted_flg = False;

  -- апдейтим старую запись (закрываем актуальность)
  update p3.tgss_dwh_dim_terminals_hist tgt
  set
    effective_to = now() - interval '1 minute'
  where 
    1=1
    and effective_to = to_timestamp('2999-12-31', 'YYYY-MM-DD') 
    and deleted_flg = False
    and terminal_id in (
        select
            t1.terminal_id 
        from p3.tgss_dwh_dim_terminals_hist t1
        left join p3.tgss_stg_del_terminals t2
        on t1.terminal_id = t2.terminal_id 
        where t2.terminal_id is null );

  -- 7 этап
  -- Обновление мета-данных
  update p3.tgss_meta
  set last_update_dt = coalesce((select max(effective_from) from p3.tgss_dwh_dim_terminals_hist), (select last_update_dt from p3.tgss_meta where schema = 'p3' and table_name = 'tgss_dwh_dim_terminals_hist'))
  where schema = 'p3' and table_name = 'tgss_dwh_dim_terminals_hist';

  -- 8 этап
  -- Фиксация транзакции
  --commit;
  '''

  cursor.execute('insert into p3.tgss_stg_del_terminals select terminal_id from p3.tgss_stg_terminals')
  conn.commit()

  cursor.execute(q)
  conn.commit()
  cursor.execute('select * from p3.tgss_dwh_dim_terminals_hist')
  records = cursor.fetchall()


"""## Passport blacklist"""

def load_passport_blacklist(file):
  cursor.execute("delete from p3.tgss_stg_passport_blacklist")
  conn.commit()
  cursor.execute("delete from p3.tgss_stg_del_passport_blacklist")
  conn.commit()
  cursor.executemany( "INSERT INTO p3.tgss_STG_passport_blacklist(entry_dt, passport_num) VALUES( %s, %s )", file.values.tolist() )
  conn.commit()


  q='''
  insert into p3.tgss_dwh_fact_passport_blacklist (entry_dt, passport_num)
  select entry_dt, passport_num from p3.tgss_stg_passport_blacklist;

  -- 4. Обновляем метаданные.
  update p3.tgss_meta
  set last_update_dt = ( select max(entry_dt) from p3.tgss_stg_passport_blacklist )
  where schema = 'p3' and table_name = 'tgss_dwh_fact_passport_blacklist' and ( select max(entry_dt) from p3.tgss_dwh_fact_passport_blacklist ) is not null;

  '''
  cursor.execute('insert into p3.tgss_stg_del_passport_blacklist select passport_num from p3.tgss_stg_passport_blacklist')
  conn.commit()

  cursor.execute(q)
  conn.commit()
  cursor.execute('select * from p3.tgss_dwh_fact_passport_blacklist')
  records = cursor.fetchall()


"""## Transactions"""

def load_transactions(file):
  cursor.execute("delete from p3.tgss_stg_transactions")
  conn.commit()
  cursor.execute("delete from p3.tgss_stg_del_transactions")
  conn.commit()
  cursor.executemany( "INSERT INTO p3.tgss_STG_transactions( transaction_id, transaction_date, amount, card_num, oper_type, oper_result, terminal) VALUES( %s, %s, %s, %s, %s, %s, %s )", file.values.tolist() )
  conn.commit()


  q='''
  insert into p3.tgss_stg_del_transactions select transaction_id from p3.tgss_stg_transactions;

  insert into p3.tgss_dwh_fact_transactions (transaction_id, transaction_date, amount, card_num, oper_type, oper_result, terminal)
  select transaction_id, transaction_date, amount, card_num, oper_type, oper_result, terminal from p3.tgss_stg_transactions;

  -- 4. Обновляем метаданные.
  update p3.tgss_meta
  set last_update_dt = ( select max(transaction_date) from p3.tgss_stg_transactions )
  where schema = 'p3' and table_name = 'tgss_dwh_fact_transactions' and ( select max(transaction_date) from p3.tgss_dwh_fact_transactions ) is not null;

  '''

  cursor.execute(q)
  conn.commit()
  cursor.execute('select * from p3.tgss_dwh_fact_transactions')
  records = cursor.fetchall()


"""## Загрузка"""

pb1 = r'data\passport_blacklist_01032021.xlsx'
pb2 = r'data\passport_blacklist_02032021.xlsx'
pb3 = r'data\passport_blacklist_03032021.xlsx'
t1 = r'data\terminals_01032021.xlsx'
t2 = r'data\terminals_02032021.xlsx'
t3 = r'data\terminals_03032021.xlsx'
tr1 = r'data\transactions_01032021.txt'
tr2 = r'data\transactions_02032021.txt'
tr3 = r'data\transactions_03032021.txt'
passport_blacklist_01 = pd.read_excel(pb1)
passport_blacklist_02 = pd.read_excel(pb2)
passport_blacklist_03 = pd.read_excel(pb3)
terminals_01 = pd.read_excel(t1)
terminals_02 = pd.read_excel(t2)
terminals_03 = pd.read_excel(t3)
transactions_01 = pd.read_csv(tr1, delimiter=';')
transactions_02 = pd.read_csv(tr2, delimiter=';')
transactions_03 = pd.read_csv(tr3, delimiter=';')

transactions_02['amount']=transactions_02['amount'].str.replace(',','.')
transactions_02 = transactions_02.astype({'amount': np.float64})
transactions_03['amount']=transactions_03['amount'].str.replace(',','.')
transactions_03 = transactions_03.astype({'amount': np.float64})
transactions_01['amount']=transactions_01['amount'].str.replace(',','.')
transactions_01 = transactions_01.astype({'amount': np.float64})



sql = open('sql_scripts.sql', 'r')
sql = str(sql.read())
sql = sql.split(';')
cheater1=sql[0]
cheater2=sql[1]
cheater3=sql[2]
cheater4=sql[3]
print('file loaded')


"""# день 1"""
print(1)
load_accounts()
print('load_accounts_finished')
load_cards()
print('load_cards_finished')
load_clients()
print('load_clients_finished')

load_terminals(terminals_01)
print('load_terminals_finished')
load_passport_blacklist(passport_blacklist_01)
print('load_passport_blacklist_finished')
load_transactions(transactions_01)
print('load_transactions_finished')

cursor.execute(cheater1)
conn.commit()
cursor.execute(cheater2)
conn.commit()
cursor.execute(cheater3)
conn.commit()
cursor.execute(cheater4)
conn.commit()
print('cheaters loaded')

"""# backup и сохранение в архив"""


os.rename(t1, t1.replace('data', 'archive') + ".backup")
os.rename(tr1, tr1.replace('data', 'archive') + ".backup")
os.rename(pb1, pb1.replace('data', 'archive') + ".backup")

"""# день 2"""
print(2)
load_accounts()
print('load_accounts_finished')
load_cards()
print('load_cards_finished')
load_clients()
print('load_clients_finished')

load_terminals(terminals_02)
print('load_terminals_finished')
load_passport_blacklist(passport_blacklist_02)
print('load_passport_blacklist_finished')
load_transactions(transactions_02)
print('load_transactions_finished')

cursor.execute(cheater1)
conn.commit()
cursor.execute(cheater2)
conn.commit()
cursor.execute(cheater3)
conn.commit()
cursor.execute(cheater4)
conn.commit()
print('cheaters loaded')
"""# backup и сохранение в архив"""

 
os.rename(t2, t2.replace('data', 'archive') + ".backup")
os.rename(tr2, tr2.replace('data', 'archive') + ".backup")
os.rename(pb2, pb2.replace('data', 'archive') + ".backup")

"""# день 3"""
print(3)
load_accounts()
print('load_accounts_finished')
load_cards()
print('load_cards_finished')
load_clients()
print('load_clients_finished')

load_terminals(terminals_03)
print('load_terminals_finished')
load_passport_blacklist(passport_blacklist_03)
print('load_passport_blacklist_finished')
load_transactions(transactions_03)
print('load_transactions_finished')

cursor.execute(cheater1)
conn.commit()
cursor.execute(cheater2)
conn.commit()
cursor.execute(cheater3)
conn.commit()
cursor.execute(cheater4)
conn.commit()
print('cheaters loaded')

# backup и сохранение в архив

os.rename(t3, t3.replace('data', 'archive') + ".backup")
os.rename(tr3, tr3.replace('data', 'archive') + ".backup")
os.rename(pb3, pb3.replace('data', 'archive') + ".backup")

print('end')